using CherryPicker.Commands;
using CherryPicker.Models;
using CherryPicker.Services;
using Microsoft.Win32;

namespace CherryPicker.ViewModels;

public sealed class MainViewModel : BaseViewModel
{
    private readonly FileSearchService _fileSearchService = new();


    private string _statusText = "Prêt.";


    public MainViewModel()
    {
        BrowseCommand = new RelayCommand(_ => Browse());
    }


    public string StatusText
    {
        get => _statusText;
        private set => SetProperty(ref _statusText, value);
    }


    public RelayCommand BrowseCommand { get; }
    public AsyncRelayCommand SearchCommand { get; }


    private void Browse()
    {
        OpenFolderDialog dialog = new()
        {
            Title = "Sélectionner le répertoire de base",
            Multiselect = false
        };

        bool? result = dialog.ShowDialog();

        if (result == true)
        {
            // Ici, vous pouvez mettre à jour la propriété de répertoire de base avec le chemin sélectionné
        }
    }

    private async Task SearchAsync()
    {
        // Déclencher la fonction appropriée du service de recherche de fichiers pour effectuer la recherche
    }


    private void UpdateProgress(SearchProgressReport progress)
    {
        // Mettre à jour l'interface utilisateur avec les informations de progression
    }


}
