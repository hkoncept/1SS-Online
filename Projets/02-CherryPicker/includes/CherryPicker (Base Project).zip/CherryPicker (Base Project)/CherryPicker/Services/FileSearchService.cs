namespace CherryPicker.Services;

public sealed class FileSearchService
{
    // Votre code ici
}
