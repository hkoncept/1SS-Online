namespace CherryPicker.Models;

public sealed class SearchResultItem
{
    public SearchResultItem(string filePath, int lineNumber, int column, string match, string preview)
    {
        FilePath = filePath;
        LineNumber = lineNumber;
        Column = column;
        Match = match;
        Preview = preview;
    }

    public string FilePath { get; }
    public int LineNumber { get; }
    public int Column { get; }
    public string Match { get; }
    public string Preview { get; }
}
