namespace CherryPicker.Models;

public sealed class SearchOptions
{
    public required string RootDirectory { get; init; }
    public required string Pattern { get; init; }
}
