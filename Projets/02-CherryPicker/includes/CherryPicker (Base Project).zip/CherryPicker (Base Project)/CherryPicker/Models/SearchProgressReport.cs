namespace CherryPicker.Models;

public sealed class SearchProgressReport
{
    public SearchProgressReport(int filesScanned, int matchesFound, string currentFile, string status)
    {
        FilesScanned = filesScanned;
        MatchesFound = matchesFound;
        CurrentFile = currentFile;
        Status = status;
    }

    public int FilesScanned { get; }
    public int MatchesFound { get; }
    public string CurrentFile { get; }
    public string Status { get; }
}
